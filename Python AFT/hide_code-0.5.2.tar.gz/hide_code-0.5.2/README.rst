Hide_code
=========

.. image:: https://img.shields.io/github/license/mashape/apistatus.svg

Release build

.. image:: https://travis-ci.org/kirbs-/hide_code.svg?branch=master

hide_code is an extension for Jupyter/IPython notebooks to selectively hide code, prompts and output. Make a notebook a code free document for exporting or presenting. Documentation at https://github.com/kirbs-/hide_code


